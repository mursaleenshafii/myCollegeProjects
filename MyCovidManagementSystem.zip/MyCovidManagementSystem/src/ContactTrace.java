/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mursa
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ContactTrace {
    private int contactId;
    private int casePatientId;
    private int contactPatientId;
    private LocalDate contactDate;

    // Constructors
    public ContactTrace() {
        // Default constructor
    }

    public ContactTrace(int casePatientId, int contactPatientId, LocalDate contactDate) {
        this.casePatientId = casePatientId;
        this.contactPatientId = contactPatientId;
        this.contactDate = contactDate;
    }

    // Getters and Setters
    public int getContactId() {
        return contactId;
    }

    public void setContactId(int contactId) {
        this.contactId = contactId;
    }

    public int getCasePatientId() {
        return casePatientId;
    }

    public void setCasePatientId(int casePatientId) {
        this.casePatientId = casePatientId;
    }

    public int getContactPatientId() {
        return contactPatientId;
    }

    public void setContactPatientId(int contactPatientId) {
        this.contactPatientId = contactPatientId;
    }

    public LocalDate getContactDate() {
        return contactDate;
    }

    public void setContactDate(LocalDate contactDate) {
        this.contactDate = contactDate;
    }

    // CRUD Operations

    // Create
    public void recordContact() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO contact_tracing (case_patient_id, contact_patient_id, contact_date) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setInt(1, this.casePatientId);
                preparedStatement.setInt(2, this.contactPatientId);
                preparedStatement.setObject(3, this.contactDate);
                preparedStatement.executeUpdate();

                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    this.contactId = generatedKeys.getInt(1);
                }
            }
        } catch (SQLException e) {
        }
    }

    // Read
    public static List<ContactTrace> getContactsByCasePatient(int casePatientId) {
        List<ContactTrace> contacts = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM contact_tracing WHERE case_patient_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, casePatientId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        ContactTrace contact = new ContactTrace();
                        contact.setContactId(resultSet.getInt("contact_id"));
                        contact.setCasePatientId(resultSet.getInt("case_patient_id"));
                        contact.setContactPatientId(resultSet.getInt("contact_patient_id"));
                        contact.setContactDate(resultSet.getObject("contact_date", LocalDate.class));
                        contacts.add(contact);
                    }
                }
            }
        } catch (SQLException e) {
        }
        return contacts;
    }

    // Other CRUD methods for updating and deleting contacts
    // Inside the ContactTrace class

// Update
public void updateContactDetails(int newContactPatientId, LocalDate newContactDate) {
    try (Connection connection = DatabaseConnection.getConnection()) {
        String query = "UPDATE contact_tracing SET contact_patient_id=?, contact_date=? WHERE contact_id=?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, newContactPatientId);
            preparedStatement.setObject(2, newContactDate);
            preparedStatement.setInt(3, this.contactId);
            preparedStatement.executeUpdate();
        }
    } catch (SQLException e) {
    }
}

// Delete
public void cancelContact() {
    try (Connection connection = DatabaseConnection.getConnection()) {
        String query = "DELETE FROM contact_tracing WHERE contact_id=?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, this.contactId);
            preparedStatement.executeUpdate();
        }
    } catch (SQLException e) {
    }
}

}

