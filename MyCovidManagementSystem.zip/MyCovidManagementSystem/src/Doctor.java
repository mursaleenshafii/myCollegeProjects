/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mursa
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Doctor {
    private int doctorId;
    private String name;
    private String specialty;
    private int hospitalId; // Assuming doctors can be assigned to a hospital

    // Constructors
    public Doctor() {
        // Default constructor
    }

    public Doctor(String name, String specialty, int hospitalId) {
        this.name = name;
        this.specialty = specialty;
        this.hospitalId = hospitalId;
    }

    // Getters and Setters
    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public int getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(int hospitalId) {
        this.hospitalId = hospitalId;
    }

    // CRUD Operations
    public void save() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO doctors (name, specialty, hospital_id) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, this.name);
                preparedStatement.setString(2, this.specialty);
                preparedStatement.setInt(3, this.hospitalId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    public void update() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "UPDATE doctors SET name=?, specialty=?, hospital_id=? WHERE doctor_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, this.name);
                preparedStatement.setString(2, this.specialty);
                preparedStatement.setInt(3, this.hospitalId);
                preparedStatement.setInt(4, this.doctorId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    public void delete() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "DELETE FROM doctors WHERE doctor_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, this.doctorId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    public static List<Doctor> getAllDoctors() {
        List<Doctor> doctors = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM doctors";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        Doctor doctor = new Doctor();
                        doctor.setDoctorId(resultSet.getInt("doctor_id"));
                        doctor.setName(resultSet.getString("name"));
                        doctor.setSpecialty(resultSet.getString("specialty"));
                        doctor.setHospitalId(resultSet.getInt("hospital_id"));
                        doctors.add(doctor);
                    }
                }
            }
        } catch (SQLException e) {
        }
        return doctors;
    }
}
