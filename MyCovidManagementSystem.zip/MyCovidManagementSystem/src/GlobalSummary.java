


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mursa
 */
public class GlobalSummary {
    private long updated;
    private long cases;
    private long todayCases;
    private long deaths;
    private long todayDeaths;
    private long recovered;
    private long todayRecovered;
    private long active;
    private long critical;
    private long casesPerOneMillion;
    private double deathsPerOneMillion;
    private long tests;
    private double testsPerOneMillion;
    private long population;
    private int affectedCountries;

    // Getters
    public long getUpdated() {
        return updated;
    }

    public long getCases() {
        return cases;
    }

    public long getTodayCases() {
        return todayCases;
    }

    public long getDeaths() {
        return deaths;
    }

    public long getTodayDeaths() {
        return todayDeaths;
    }

    public long getRecovered() {
        return recovered;
    }

    public long getTodayRecovered() {
        return todayRecovered;
    }

    public long getActive() {
        return active;
    }

    public long getCritical() {
        return critical;
    }

    public long getCasesPerOneMillion() {
        return casesPerOneMillion;
    }

    public double getDeathsPerOneMillion() {
        return deathsPerOneMillion;
    }

    public long getTests() {
        return tests;
    }

    public double getTestsPerOneMillion() {
        return testsPerOneMillion;
    }

    public long getPopulation() {
        return population;
    }

    public int getAffectedCountries() {
        return affectedCountries;
    }

    // Setters
    public void setUpdated(long updated) {
        this.updated = updated;
    }

    public void setCases(long cases) {
        this.cases = cases;
    }

    public void setTodayCases(long todayCases) {
        this.todayCases = todayCases;
    }

    public void setDeaths(long deaths) {
        this.deaths = deaths;
    }

    public void setTodayDeaths(long todayDeaths) {
        this.todayDeaths = todayDeaths;
    }

    public void setRecovered(long recovered) {
        this.recovered = recovered;
    }

    public void setTodayRecovered(long todayRecovered) {
        this.todayRecovered = todayRecovered;
    }

    public void setActive(long active) {
        this.active = active;
    }

    public void setCritical(long critical) {
        this.critical = critical;
    }

    public void setCasesPerOneMillion(long casesPerOneMillion) {
        this.casesPerOneMillion = casesPerOneMillion;
    }

    public void setDeathsPerOneMillion(double deathsPerOneMillion) {
        this.deathsPerOneMillion = deathsPerOneMillion;
    }

    public void setTests(long tests) {
        this.tests = tests;
    }

    public void setTestsPerOneMillion(double testsPerOneMillion) {
        this.testsPerOneMillion = testsPerOneMillion;
    }

    public void setPopulation(long population) {
        this.population = population;
    }

    public void setAffectedCountries(int affectedCountries) {
        this.affectedCountries = affectedCountries;
    }

    // Other methods...
    
    @Override
    public String toString() {
        return "GlobalSummary{" +
                "updated=" + updated +
                ",\n cases=" + cases +
                ",\n todayCases=" + todayCases +
                ",\n deaths=" + deaths +
                ",\n todayDeaths=" + todayDeaths +
                ",\n recovered=" + recovered +
                ",\n todayRecovered=" + todayRecovered +
                ",\n active=" + active +
                ",\n critical=" + critical +
                ",\n casesPerOneMillion=" + casesPerOneMillion +
                ",\n deathsPerOneMillion=" + deathsPerOneMillion +
                ",\n tests=" + tests +
                ",\n testsPerOneMillion=" + testsPerOneMillion +
                ",\n population=" + population +
                ",\n affectedCountries=" + affectedCountries +
                '}';
    }
}

