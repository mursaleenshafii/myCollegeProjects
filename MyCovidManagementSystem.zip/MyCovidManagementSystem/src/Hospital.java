/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mursa
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Hospital {
    private int hospitalId;  // Auto-generated in the database
    private String name;
    private String location;
    private int totalBeds;
    private int availableBeds;

    // Constructors
    public Hospital() {
        // Default constructor
    }

    public Hospital(String name, String location, int totalBeds, int availableBeds) {
        this.name = name;
        this.location = location;
        this.totalBeds = totalBeds;
        this.availableBeds = availableBeds;
    }

    // Getters and Setters
    public int getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(int hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getTotalBeds() {
        return totalBeds;
    }

    public void setTotalBeds(int totalBeds) {
        this.totalBeds = totalBeds;
    }

    public int getAvailableBeds() {
        return availableBeds;
    }

    public void setAvailableBeds(int availableBeds) {
        this.availableBeds = availableBeds;
    }

    // CRUD Operations
    public void save() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO hospitals (name, location, total_beds, available_beds) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setString(1, this.name);
                preparedStatement.setString(2, this.location);
                preparedStatement.setInt(3, this.totalBeds);
                preparedStatement.setInt(4, this.availableBeds);
                preparedStatement.executeUpdate();

                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    this.hospitalId = generatedKeys.getInt(1);
                }

                System.out.println("Hospital added successfully! Hospital ID: " + this.hospitalId);
            }
        } catch (SQLException e) {
        }
    }

    public void update() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "UPDATE hospitals SET name=?, location=?, total_beds=?, available_beds=? WHERE hospital_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, this.name);
                preparedStatement.setString(2, this.location);
                preparedStatement.setInt(3, this.totalBeds);
                preparedStatement.setInt(4, this.availableBeds);
                preparedStatement.setInt(5, this.hospitalId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    public void delete() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "DELETE FROM hospitals WHERE hospital_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, this.hospitalId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    public static List<Hospital> getAllHospitals() {
        List<Hospital> hospitals = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM hospitals";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        Hospital hospital = new Hospital();
                        hospital.setHospitalId(resultSet.getInt("hospital_id"));
                        hospital.setName(resultSet.getString("name"));
                        hospital.setLocation(resultSet.getString("location"));
                        hospital.setTotalBeds(resultSet.getInt("total_beds"));
                        hospital.setAvailableBeds(resultSet.getInt("available_beds"));
                        hospitals.add(hospital);
                    }
                }
            }
            System.out.println("Number of hospitals retrieved: " + hospitals.size());
        } catch (SQLException e) {
        }
        return hospitals;
    }
}