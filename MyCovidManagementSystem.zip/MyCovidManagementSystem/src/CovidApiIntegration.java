/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mursa
 */
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;


import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.StandardCharsets;


public class CovidApiIntegration {

    private static final String API_URL = "https://disease.sh/v3/covid-19/all";

    public static void main(String[] args) {
        fetchCovidData();
    }

    private static void fetchCovidData() {
        try {
            // Make API call
            URL url = new URL(API_URL);
            try (Reader reader = new InputStreamReader(url.openStream(), StandardCharsets.UTF_8)) {
                // Parse the JSON response
                JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();

                // Convert JSON to GlobalSummary object
                Gson gson = new Gson();
                GlobalSummary globalSummary = gson.fromJson(json, GlobalSummary.class);

                // Print the global summary
                System.out.println("Global Summary: " + globalSummary);
            }
        } catch (IOException e) {
            System.err.println("Error during API call: " + e.getMessage());
        }
    }
}


