/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mursa
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Appointment {
    private int appointmentId;
    private int patientId;
    private int doctorId;
    private LocalDate appointmentDate;
    private String status;

    // Constructors
    public Appointment() {
        // Default constructor
    }

    public Appointment(int patientId, int doctorId, LocalDate appointmentDate, String status) {
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.appointmentDate = appointmentDate;
        this.status = status;
    }

    // Getters and Setters
    public int getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public LocalDate getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(LocalDate appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // CRUD Operations

    // Create
    public void scheduleAppointment() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO appointments (patient_id, doctor_id, appointment_date, status) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setInt(1, this.patientId);
                preparedStatement.setInt(2, this.doctorId);
                preparedStatement.setObject(3, this.appointmentDate);
                preparedStatement.setString(4, this.status);
                preparedStatement.executeUpdate();

                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    this.appointmentId = generatedKeys.getInt(1);
                }
            }
        } catch (SQLException e) {
        }
    }

    // Read
    public static List<Appointment> getAppointmentsByPatient(int patientId) {
        List<Appointment> appointments = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM appointments WHERE patient_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, patientId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        Appointment appointment = new Appointment();
                        appointment.setAppointmentId(resultSet.getInt("appointment_id"));
                        appointment.setPatientId(resultSet.getInt("patient_id"));
                        appointment.setDoctorId(resultSet.getInt("doctor_id"));
                        appointment.setAppointmentDate(resultSet.getObject("appointment_date", LocalDate.class));
                        appointment.setStatus(resultSet.getString("status"));
                        appointments.add(appointment);
                    }
                }
            }
        } catch (SQLException e) {
        }
        return appointments;
    }

    public static List<Appointment> getAppointmentsByDoctor(int doctorId) {
        List<Appointment> appointments = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM appointments WHERE doctor_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, doctorId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        Appointment appointment = new Appointment();
                        appointment.setAppointmentId(resultSet.getInt("appointment_id"));
                        appointment.setPatientId(resultSet.getInt("patient_id"));
                        appointment.setDoctorId(resultSet.getInt("doctor_id"));
                        appointment.setAppointmentDate(resultSet.getObject("appointment_date", LocalDate.class));
                        appointment.setStatus(resultSet.getString("status"));
                        appointments.add(appointment);
                    }
                }
            }
        } catch (SQLException e) {
        }
        return appointments;
    }

    // Update
    public void updateAppointmentStatus(String newStatus) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "UPDATE appointments SET status=? WHERE appointment_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, newStatus);
                preparedStatement.setInt(2, this.appointmentId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    // Delete
    public void cancelAppointment() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "DELETE FROM appointments WHERE appointment_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, this.appointmentId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }
}

