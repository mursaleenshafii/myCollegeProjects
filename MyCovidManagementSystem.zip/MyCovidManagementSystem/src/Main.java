/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mursa
 */
import java.util.List;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Main {
    private static final boolean loggedIn = false;
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        

        while (true) {
            System.out.println("\n--patient's Menu---");
            System.out.println("0. Login");
            System.out.println("1. Add Patient");
            System.out.println("2. Update Patient");
            System.out.println("3. Delete Patient");
            System.out.println("4. View All Patients");
            System.out.println("\n--Doctor's Menu--");
            System.out.println("5. Add Doctor");
            System.out.println("6. Update Doctor");
            System.out.println("7. Delete Doctor");
            System.out.println("8. View All Doctors");
            System.out.println("\n--Hospital Menu---");
            System.out.println("9. Add Hospital");
            System.out.println("10. Update Hospital");
            System.out.println("11. Delete Hospital");
            System.out.println("12. View All Hospitals");
            System.out.println("\n--Appointments Menu---");
            System.out.println("13. Schedule Appointment");
            System.out.println("14. View Patient Appointments");
            System.out.println("15. View Doctor Appointments");
            System.out.println("16. Update Appointment Status");
            System.out.println("17. Cancel Appointment");
            System.out.println("\n--Test Menu---");
            System.out.println("18. Request Test");
            System.out.println("19. View Patient Test Requests");
            System.out.println("20. Update Test Request Status");
            System.out.println("21. Cancel Test Request");
            System.out.println("\n--- Vaccination Menu ---");
            System.out.println("22. Administer Vaccination");
            System.out.println("23. View Patient Vaccinations");
            System.out.println("24. Update Vaccination Details");
            System.out.println("25. Cancel Vaccination");
            System.out.println("\n--- Contact Tracing Menu ---");
            System.out.println("26. Record Contact");
            System.out.println("27. View Case Patient Contacts");
            System.out.println("28. Update Contact Details");
            System.out.println("29. Cancel Contact");
            System.out.println("\n--- Reporting and Analytics Menu ---");
            System.out.println("30. Record Daily Statistics");
            System.out.println("31. Record Patient Status History");
            System.out.println("32. Record Doctor Availability");
            System.out.println("33. Record Hospital Occupancy");
            System.out.println("34. Record Test Results Summary");
            System.out.println("\n---View Analytics Menu---");
            System.out.println("35. View Daily Statistics");
            System.out.println("36. View Patient Status History");
            System.out.println("37. View Doctor Availability");
            System.out.println("38. View Hospital Occupancy");
            System.out.println("39. View Test Result Summary");
            System.out.println("\n---Inventory Management--");
            System.out.println("40. Add Medical Inventory Item");
            System.out.println("41. Update Medical Inventory Item");
            System.out.println("42. View Medical Inventory Item");
            System.out.println("43. Delete Medical Inventory Item");
            System.out.println("\n---Public Information Menu---");
            System.out.println("44. Add Public Information");
            System.out.println("45. View Public Information");
            System.out.println("\n---Employee Health Information---");
            System.out.println("46. Add Employee Health Record");
            System.out.println("47. View Employee health Record");
            System.out.println("\n---Emergency Response Menu---");
            System.out.println("48. Add Emergency Response");
            System.out.println("49. View Emergency Response");
            
            System.out.println("50. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 0:
                    login();
                    checkLogin();
                    break;
                case 1:
                    // Add Patient
                    
                    addPatient(scanner);
                    checkLogin();
                    break;
                case 2:
                    // Update Patient
                    
                    checkLogin();
                    updatePatient(scanner);
                    break;
                case 3:
                    // Delete Patient
                    deletePatient(scanner);
                    break;
                case 4:
                    // View All Patients
                    
                    viewAllPatients();
                    break;
                    case 5:
                    // Add Doctor
                    addDoctor(scanner);
                    break;
                case 6:
                    // Update Doctor
                    updateDoctor(scanner);
                    break;
                case 7:
                    // Delete Doctor
                    deleteDoctor(scanner);
                    break;
                case 8:
                    // View All Doctors
                    viewAllDoctors();
                    break;
                    case 9:
                    // Add Hospital
                    addHospital(scanner);
                    break;
                case 10:
                    // Update Hospital
                    updateHospital(scanner);
                    break;
                case 11:
                    // Delete Hospital
                    deleteHospital(scanner);
                    break;
                case 12:
                    // View All Hospitals
                    viewAllHospitals();
                    break;
                case 13:
                    scheduleAppointment(scanner);
                    break;
                case 14:
                    viewPatientAppointments(scanner);
                    break;
                case 15:
                    viewDoctorAppointments(scanner);
                    break;
                case 16:
                    updateAppointmentStatus(scanner);
                    break;
                case 17:
                    cancelAppointment(scanner);
                    break;
                case 18:
                // Request Test
                requestTest(scanner);
                break;
                case 19:
                // View Patient Test Requests
                viewPatientTestRequests(scanner);
                break;
                case 20:
                // Update Test Request Status
                updateTestRequestStatus(scanner);
                break;
                case 21:
                // Cancel Test Request
                cancelTestRequest(scanner);
                break;
                case 22:
                // Administer Vaccination
                administerVaccination(scanner);
                break;
                case 23:
                // View Patient Vaccinations
                viewPatientVaccinations(scanner);
                break;
                case 24:
                // Update Vaccination Details
                updateVaccinationDetails(scanner);
                break;
                case 25:
                // Cancel Vaccination
                cancelVaccination(scanner);
                break;
                case 26:
                // Record Contact
                recordContact(scanner);
                break;
                case 27:
                // View Case Patient Contacts
                viewCasePatientContacts(scanner);
                break;
                case 28:
                // Update Contact Details
                updateContactDetails(scanner);
                break;
                case 29:
                // Cancel Contact
                cancelContact(scanner);
                break;
                case 30:
                    // Record Daily Statistics
                    recordDailyStatistics(scanner);
                    break;
                case 31:
                    // Record Patient Status History
                    recordPatientStatusHistory(scanner);
                    break;
                case 32:
                    // Record Doctor Availability
                    recordDoctorAvailability(scanner);
                    break;
                case 33:
                    // Record Hospital Occupancy
                    recordHospitalOccupancy(scanner);
                    break;
                case 34:
                    // Record Test Results Summary
                    recordTestResultsSummary(scanner);
                    break;
                    case 35:
                    // View Daily Statistics
                    viewDailyStatistics(scanner);
                    break;
                    case 36:
                    // View Patient Status History
                    viewPatientStatusHistory(scanner);
                    break;
                    case 37:
                    // View Doctor Availablity
                    viewDoctorAvailability(scanner);
                    break;
                    case 38:
                    // View Hospital Occupancy
                    viewHospitalOccupancy(scanner);
                    break;
                    case 39:
                    // View Test Result Summary
                    viewTestResultsSummary(scanner);
                    break;
                    case 40:
                    // Add Medical Inventory Item
                    addMedicalInventoryItem(scanner);
                    break;
                    case 41:
                    // Update Medical Inventory Item
                    updateMedicalInventoryQuantity(scanner);
                    break;
                    case 42:
                    // View Medical Inventory Item   
                    viewMedicalInventory();
                    break;
                    case 43:
                    // Delete Medical Inventory Item    
                    deleteMedicalInventoryItem(scanner);
                    break;
                    case 44:
                    //Add Public Information
                    addPublicInformation(scanner);
                    break;
                    case 45:
                    // View Public Information
                    viewPublicInformation();
                    break;
                    case 46:
                    addEmployeeHealthRecord(scanner);
                    break;
                    case 47:
                    viewEmployeeHealthRecords(scanner);
                    break;
                    case 48:
                    addEmergencyResponse(scanner);
                    break;
                    case 49:
                    viewEmergencyResponseIncidents();
                    break;
                        
                    case 50:
                    System.out.println("Exiting the system. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
        
    }

    private static void addPatient(Scanner scanner) {
        System.out.print("Enter patient name: ");
        String name = scanner.nextLine();

        System.out.print("Enter patient age: ");
        int age = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter patient address: ");
        String address = scanner.nextLine();

        System.out.print("Enter patient status: ");
        String status = scanner.nextLine();

        System.out.print("Enter patient test result: ");
        String testResult = scanner.nextLine();

        Patient patient = new Patient(name, age, address, status, testResult);
        patient.save();
        System.out.println("Patient added successfully!\n");
    }

    private static void updatePatient(Scanner scanner) {
        System.out.print("Enter patient ID to update: ");
        int patientId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Patient existingPatient = retrievePatientById(patientId);

        if (existingPatient != null) {
            System.out.print("Enter updated patient name: ");
            String name = scanner.nextLine();

            System.out.print("Enter updated patient age: ");
            int age = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter updated patient address: ");
            String address = scanner.nextLine();

            System.out.print("Enter updated patient status: ");
            String status = scanner.nextLine();

            System.out.print("Enter updated patient test result: ");
            String testResult = scanner.nextLine();

            existingPatient.setName(name);
            existingPatient.setAge(age);
            existingPatient.setAddress(address);
            existingPatient.setStatus(status);
            existingPatient.setTestResult(testResult);

            existingPatient.update();
            System.out.println("Patient updated successfully!\n");
        } else {
            System.out.println("Patient not found.\n");
        }
    }

    private static void deletePatient(Scanner scanner) {
        System.out.print("Enter patient ID to delete: ");
        int patientId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Patient existingPatient = retrievePatientById(patientId);

        if (existingPatient != null) {
            existingPatient.delete();
            System.out.println("Patient deleted successfully!\n");
        } else {
            System.out.println("Patient not found.\n");
        }
    }

    private static void viewAllPatients() {
        List<Patient> patients = Patient.getAllPatients();
        System.out.println("\n--- All Patients ---");

        for (Patient patient : patients) {
            System.out.println("Patient ID: " + patient.getPatientId());
            System.out.println("Name: " + patient.getName());
            System.out.println("Age: " + patient.getAge());
            System.out.println("Address: " + patient.getAddress());
            System.out.println("Status: " + patient.getStatus());
            System.out.println("Test Result: " + patient.getTestResult());
            System.out.println("--------------");
        }

        System.out.println();
    }

    private static Patient retrievePatientById(int patientId) {
        List<Patient> patients = Patient.getAllPatients();

        for (Patient patient : patients) {
            if (patient.getPatientId() == patientId) {
                return patient;
            }
        }
        return null;
    }
     private static void addDoctor(Scanner scanner) {
        System.out.print("Enter doctor name: ");
        String name = scanner.nextLine();

        System.out.print("Enter doctor specialty: ");
        String specialty = scanner.nextLine();

        System.out.print("Enter hospital ID (if applicable): ");
        int hospitalId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Doctor doctor = new Doctor();
        doctor.setName(name);
        doctor.setSpecialty(specialty);
        doctor.setHospitalId(hospitalId);
        doctor.save();
        System.out.println("Doctor added successfully!\n");
    }

    private static void updateDoctor(Scanner scanner) {
        System.out.print("Enter doctor ID to update: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Doctor existingDoctor = retrieveDoctorById(doctorId);

        if (existingDoctor != null) {
            System.out.print("Enter updated doctor name: ");
            String name = scanner.nextLine();

            System.out.print("Enter updated doctor specialty: ");
            String specialty = scanner.nextLine();

            System.out.print("Enter updated hospital ID (if applicable): ");
            int hospitalId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            existingDoctor.setName(name);
            existingDoctor.setSpecialty(specialty);
            existingDoctor.setHospitalId(hospitalId);

            existingDoctor.update();
            System.out.println("Doctor updated successfully!\n");
        } else {
            System.out.println("Doctor not found.\n");
        }
    }

    private static void deleteDoctor(Scanner scanner) {
        System.out.print("Enter doctor ID to delete: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Doctor existingDoctor = retrieveDoctorById(doctorId);

        if (existingDoctor != null) {
            existingDoctor.delete();
            System.out.println("Doctor deleted successfully!\n");
        } else {
            System.out.println("Doctor not found.\n");
        }
    }

    private static void viewAllDoctors() {
        List<Doctor> doctors = Doctor.getAllDoctors();
        System.out.println("\n--- All Doctors ---");

        for (Doctor doctor : doctors) {
            System.out.println("Doctor ID: " + doctor.getDoctorId());
            System.out.println("Name: " + doctor.getName());
            System.out.println("Specialty: " + doctor.getSpecialty());
            System.out.println("Hospital ID: " + doctor.getHospitalId());
            System.out.println("--------------");
        }

        System.out.println();
    }

    private static Doctor retrieveDoctorById(int doctorId) {
        List<Doctor> doctors = Doctor.getAllDoctors();

        for (Doctor doctor : doctors) {
            if (doctor.getDoctorId() == doctorId) {
                return doctor;
            }
        }
        return null;
    }
    private static void addHospital(Scanner scanner) {
        System.out.print("Enter hospital name: ");
        String name = scanner.nextLine();

        System.out.print("Enter hospital location: ");
        String location = scanner.nextLine();

        System.out.print("Enter total number of beds: ");
        int totalBeds = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter available beds: ");
        int availableBeds = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Hospital hospital = new Hospital();
        hospital.setName(name);
        hospital.setLocation(location);
        hospital.setTotalBeds(totalBeds);
        hospital.setAvailableBeds(availableBeds);
        hospital.save();
        System.out.println("Hospital added successfully!\n");
    }

    private static void updateHospital(Scanner scanner) {
        System.out.print("Enter hospital ID to update: ");
        int hospitalId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Hospital existingHospital = retrieveHospitalById(hospitalId);

        if (existingHospital != null) {
            System.out.print("Enter updated hospital name: ");
            String name = scanner.nextLine();

            System.out.print("Enter updated hospital location: ");
            String location = scanner.nextLine();

            System.out.print("Enter updated total number of beds: ");
            int totalBeds = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter updated available beds: ");
            int availableBeds = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            existingHospital.setName(name);
            existingHospital.setLocation(location);
            existingHospital.setTotalBeds(totalBeds);
            existingHospital.setAvailableBeds(availableBeds);

            existingHospital.update();
            System.out.println("Hospital updated successfully!\n");
        } else {
            System.out.println("Hospital not found.\n");
        }
    }

    private static void deleteHospital(Scanner scanner) {
        System.out.print("Enter hospital ID to delete: ");
        int hospitalId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Hospital existingHospital = retrieveHospitalById(hospitalId);

        if (existingHospital != null) {
            existingHospital.delete();
            System.out.println("Hospital deleted successfully!\n");
        } else {
            System.out.println("Hospital not found.\n");
        }
    }

    private static void viewAllHospitals() {
    List<Hospital> hospitals = Hospital.getAllHospitals();
    System.out.println("\n--- All Hospitals ---");

    if (hospitals.isEmpty()) {
        System.out.println("No hospitals found.");
    } else {
        for (Hospital hospital : hospitals) {
            System.out.println("Hospital ID: " + hospital.getHospitalId());
            System.out.println("Name: " + hospital.getName());
            System.out.println("Location: " + hospital.getLocation());
            System.out.println("Total Beds: " + hospital.getTotalBeds());
            System.out.println("Available Beds: " + hospital.getAvailableBeds());
            System.out.println("--------------");
        }
    }

    System.out.println();
}


    private static Hospital retrieveHospitalById(int hospitalId) {
        List<Hospital> hospitals = Hospital.getAllHospitals();

        for (Hospital hospital : hospitals) {
            if (hospital.getHospitalId() == hospitalId) {
                return hospital;
            }
        }
        return null;
    }
    private static void scheduleAppointment(Scanner scanner) {
        System.out.print("Enter patient ID: ");
        int patientId = scanner.nextInt();
        System.out.print("Enter doctor ID: ");
        int doctorId = scanner.nextInt();
        System.out.print("Enter appointment date (YYYY-MM-DD): ");
        String dateInput = scanner.next();
        LocalDate appointmentDate = LocalDate.parse(dateInput);

        Appointment appointment = new Appointment(patientId, doctorId, appointmentDate, "Scheduled");
        appointment.scheduleAppointment();
        System.out.println("Appointment scheduled successfully!");
    }

    private static void viewPatientAppointments(Scanner scanner) {
        System.out.print("Enter patient ID: ");
        int patientId = scanner.nextInt();

        List<Appointment> appointments = Appointment.getAppointmentsByPatient(patientId);
        displayAppointments(appointments);
    }

    private static void viewDoctorAppointments(Scanner scanner) {
        System.out.print("Enter doctor ID: ");
        int doctorId = scanner.nextInt();

        List<Appointment> appointments = Appointment.getAppointmentsByDoctor(doctorId);
        displayAppointments(appointments);
    }

    private static void updateAppointmentStatus(Scanner scanner) {
        System.out.print("Enter appointment ID: ");
        int appointmentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new appointment status: ");
        String newStatus = scanner.nextLine();

        Appointment appointment = new Appointment();
        appointment.setAppointmentId(appointmentId);
        appointment.updateAppointmentStatus(newStatus);
        System.out.println("Appointment status updated successfully!");
    }

    private static void cancelAppointment(Scanner scanner) {
        System.out.print("Enter appointment ID: ");
        int appointmentId = scanner.nextInt();

        Appointment appointment = new Appointment();
        appointment.setAppointmentId(appointmentId);
        appointment.cancelAppointment();
        System.out.println("Appointment canceled successfully!");
    }

    private static void displayAppointments(List<Appointment> appointments) {
        System.out.println("\n--- Appointments ---");
        for (Appointment appointment : appointments) {
            System.out.println("Appointment ID: " + appointment.getAppointmentId());
            System.out.println("Patient ID: " + appointment.getPatientId());
            System.out.println("Doctor ID: " + appointment.getDoctorId());
            System.out.println("Appointment Date: " + appointment.getAppointmentDate());
            System.out.println("Status: " + appointment.getStatus());
            System.out.println("---------------------");
        }
    }
    
    private static void requestTest(Scanner scanner) {
    System.out.print("Enter patient ID: ");
    int patientId = scanner.nextInt();

    // Check if the patient exists
    Patient patient = Patient.getPatientById(patientId);
    if (patient == null) {
        System.out.println("Patient with ID " + patientId + " not found.");
        return;
    }

    // Get the test date
    System.out.print("Enter test date (YYYY-MM-DD): ");
    String dateInput = scanner.next();
    LocalDate testDate = LocalDate.parse(dateInput);

    // Create a new test request
    TestRequest testRequest = new TestRequest(patientId, testDate, "Pending", null);
    testRequest.requestTest();

    System.out.println("Test requested successfully for patient " + patientId + ".");
}

private static void viewPatientTestRequests(Scanner scanner) {
    System.out.print("Enter patient ID: ");
    int patientId = scanner.nextInt();

    List<TestRequest> testRequests = TestRequest.getTestRequestsByPatient(patientId);
    displayTestRequests(testRequests);
}

private static void updateTestRequestStatus(Scanner scanner) {
    System.out.print("Enter test request ID: ");
    int requestId = scanner.nextInt();
    scanner.nextLine(); // Consume newline
    System.out.print("Enter new test request status: ");
    String newStatus = scanner.nextLine();

    TestRequest testRequest = new TestRequest();
    testRequest.setRequestId(requestId);
    testRequest.updateTestRequestStatus(newStatus);
    System.out.println("Test request status updated successfully!");
    
}

private static void cancelTestRequest(Scanner scanner) {
    System.out.print("Enter test request ID: ");
    int requestId = scanner.nextInt();

    TestRequest testRequest = new TestRequest();
    testRequest.setRequestId(requestId);
    testRequest.cancelTestRequest();
    System.out.println("Test request canceled successfully!");
}

private static void displayTestRequests(List<TestRequest> testRequests) {
    System.out.println("\n--- Test Requests ---");
    for (TestRequest testRequest : testRequests) {
        System.out.println("Request ID: " + testRequest.getRequestId());
        System.out.println("Patient ID: " + testRequest.getPatientId());
        System.out.println("Test Date: " + testRequest.getTestDate());
        System.out.println("Status: " + testRequest.getStatus());
        System.out.println("Result: " + testRequest.getResult());
        System.out.println("---------------------");
    }
}
private static void administerVaccination(Scanner scanner) {
    System.out.print("Enter patient ID: ");
    int patientId = scanner.nextInt();
    scanner.nextLine(); // Consume newline

    System.out.print("Enter vaccine name: ");
    String vaccineName = scanner.nextLine();

    System.out.print("Enter dose number: ");
    int doseNumber = scanner.nextInt();

    System.out.print("Enter vaccination date (YYYY-MM-DD): ");
    String dateInput = scanner.next();
    LocalDate vaccinationDate = LocalDate.parse(dateInput);

    Vaccination vaccination = new Vaccination(patientId, vaccineName, doseNumber, vaccinationDate);
    vaccination.administerVaccination();

    System.out.println("Vaccination administered successfully for patient " + patientId + ".");
}

private static void viewPatientVaccinations(Scanner scanner) {
    System.out.print("Enter patient ID: ");
    int patientId = scanner.nextInt();

    List<Vaccination> vaccinations = Vaccination.getVaccinationsByPatient(patientId);
    displayVaccinations(vaccinations);
}

private static void updateVaccinationDetails(Scanner scanner) {
    System.out.print("Enter vaccination ID: ");
    int vaccinationId = scanner.nextInt();
    scanner.nextLine(); // Consume newline

    System.out.print("Enter new vaccine name: ");
    String newVaccineName = scanner.nextLine();

    System.out.print("Enter new dose number: ");
    int newDoseNumber = scanner.nextInt();

    System.out.print("Enter new vaccination date (YYYY-MM-DD): ");
    String newDateInput = scanner.next();
    LocalDate newVaccinationDate = LocalDate.parse(newDateInput);

    Vaccination vaccination = new Vaccination();
    vaccination.setVaccinationId(vaccinationId);
    vaccination.updateVaccinationDetails(newVaccineName, newDoseNumber, newVaccinationDate);
    System.out.println("Vaccination details updated successfully!");
}

private static void cancelVaccination(Scanner scanner) {
    System.out.print("Enter vaccination ID: ");
    int vaccinationId = scanner.nextInt();

    Vaccination vaccination = new Vaccination();
    vaccination.setVaccinationId(vaccinationId);
    vaccination.cancelVaccination();
    System.out.println("Vaccination canceled successfully!");
}

private static void displayVaccinations(List<Vaccination> vaccinations) {
    System.out.println("\n--- Vaccinations ---");
    for (Vaccination vaccination : vaccinations) {
        System.out.println("Vaccination ID: " + vaccination.getVaccinationId());
        System.out.println("Patient ID: " + vaccination.getPatientId());
        System.out.println("Vaccine Name: " + vaccination.getVaccineName());
        System.out.println("Dose Number: " + vaccination.getDoseNumber());
        System.out.println("Vaccination Date: " + vaccination.getVaccinationDate());
        System.out.println("---------------------");
    }

}
private static void recordContact(Scanner scanner) {
    System.out.print("Enter COVID-positive case patient ID: ");
    int casePatientId = scanner.nextInt();
    scanner.nextLine(); // Consume newline

    System.out.print("Enter exposed individual ID: ");
    int contactPatientId = scanner.nextInt();

    System.out.print("Enter contact date (YYYY-MM-DD): ");
    String dateInput = scanner.next();
    LocalDate contactDate = LocalDate.parse(dateInput);

    ContactTrace contact = new ContactTrace(casePatientId, contactPatientId, contactDate);
    contact.recordContact();

    System.out.println("Contact recorded successfully!");
}

private static void viewCasePatientContacts(Scanner scanner) {
    System.out.print("Enter COVID-positive case patient ID: ");
    int casePatientId = scanner.nextInt();

    List<ContactTrace> contacts = ContactTrace.getContactsByCasePatient(casePatientId);
    displayContacts(contacts);
}

private static void updateContactDetails(Scanner scanner) {
    System.out.print("Enter contact ID: ");
    int contactId = scanner.nextInt();
    scanner.nextLine(); // Consume newline

    System.out.print("Enter new exposed individual ID: ");
    int newContactPatientId = scanner.nextInt();

    System.out.print("Enter new contact date (YYYY-MM-DD): ");
    String newDateInput = scanner.next();
    LocalDate newContactDate = LocalDate.parse(newDateInput);

    ContactTrace contact = new ContactTrace();
    contact.setContactId(contactId);
    contact.updateContactDetails(newContactPatientId, newContactDate);
    System.out.println("Contact details updated successfully!");
}

private static void cancelContact(Scanner scanner) {
    System.out.print("Enter contact ID: ");
    int contactId = scanner.nextInt();

    ContactTrace contact = new ContactTrace();
    contact.setContactId(contactId);
    contact.cancelContact();
    System.out.println("Contact canceled successfully!");
}

private static void displayContacts(List<ContactTrace> contacts) {
    System.out.println("\n--- Contacts ---");
    for (ContactTrace contact : contacts) {
        System.out.println("Contact ID: " + contact.getContactId());
        System.out.println("Case Patient ID: " + contact.getCasePatientId());
        System.out.println("Contact Patient ID: " + contact.getContactPatientId());
        System.out.println("Contact Date: " + contact.getContactDate());
        System.out.println("---------------------");
    }
}
 private static void recordDailyStatistics(Scanner scanner) {
        System.out.println("\n--- Record Daily Statistics ---");

        System.out.print("Enter date (YYYY-MM-DD): ");
        String dateInput = scanner.next();
        LocalDate date = LocalDate.parse(dateInput);

        System.out.print("Enter total patients: ");
        int totalPatients = scanner.nextInt();

        System.out.print("Enter total doctors: ");
        int totalDoctors = scanner.nextInt();

        System.out.print("Enter total appointments: ");
        int totalAppointments = scanner.nextInt();

        System.out.print("Enter new cases: ");
        int newCases = scanner.nextInt();

        System.out.print("Enter recovered cases: ");
        int recoveredCases = scanner.nextInt();

        System.out.print("Enter deaths: ");
        int deaths = scanner.nextInt();

        // Call the method to record daily statistics
        CovidAnalytics.recordDailyStatistics(date, totalPatients, totalDoctors, totalAppointments, newCases, recoveredCases, deaths);

        System.out.println("Daily statistics recorded successfully!");
    }

    private static void recordPatientStatusHistory(Scanner scanner) {
        System.out.println("\n--- Record Patient Status History ---");

        System.out.print("Enter patient ID: ");
        int patientId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new status: ");
        String status = scanner.nextLine();

        System.out.print("Enter status date (YYYY-MM-DD): ");
        String dateInput = scanner.next();
        LocalDate statusDate = LocalDate.parse(dateInput);

        // Call the method to record patient status history
        CovidAnalytics.recordPatientStatusHistory(patientId, status, statusDate);

        System.out.println("Patient status history recorded successfully!");
    }

    private static void recordDoctorAvailability(Scanner scanner) {
        System.out.println("\n--- Record Doctor Availability ---");

        System.out.print("Enter doctor ID: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter date (YYYY-MM-DD): ");
        String dateInput = scanner.next();
        LocalDate date = LocalDate.parse(dateInput);

        System.out.print("Enter available slots: ");
        int availableSlots = scanner.nextInt();

        System.out.print("Enter booked slots: ");
        int bookedSlots = scanner.nextInt();

        // Call the method to record doctor availability
        CovidAnalytics.recordDoctorAvailability(doctorId, date, availableSlots, bookedSlots);

        System.out.println("Doctor availability recorded successfully!");
    }

    private static void recordHospitalOccupancy(Scanner scanner) {
        System.out.println("\n--- Record Hospital Occupancy ---");

        System.out.print("Enter hospital ID: ");
        int hospitalId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter date (YYYY-MM-DD): ");
        String dateInput = scanner.next();
        LocalDate date = LocalDate.parse(dateInput);

        System.out.print("Enter total beds: ");
        int totalBeds = scanner.nextInt();

        System.out.print("Enter occupied beds: ");
        int occupiedBeds = scanner.nextInt();

        // Call the method to record hospital occupancy
        CovidAnalytics.recordHospitalOccupancy(hospitalId, date, totalBeds, occupiedBeds);

        System.out.println("Hospital occupancy recorded successfully!");
    }

    private static void recordTestResultsSummary(Scanner scanner) {
        System.out.println("\n--- Record Test Results Summary ---");

        System.out.print("Enter test result: ");
        String result = scanner.next();

        System.out.print("Enter total tests: ");
        int totalTests = scanner.nextInt();

        System.out.print("Enter positive tests: ");
        int positiveTests = scanner.nextInt();

        System.out.print("Enter negative tests: ");
        int negativeTests = scanner.nextInt();

        // Call the method to record test results summary
        CovidAnalytics.recordTestResultsSummary(result, totalTests, positiveTests, negativeTests);

        System.out.println("Test results summary recorded successfully!");
    }
    private static void viewDailyStatistics(Scanner scanner) {
    System.out.println("\n--- View Daily Statistics ---");

    System.out.print("Enter date (YYYY-MM-DD): ");
    String dateInput = scanner.next();
    LocalDate date = LocalDate.parse(dateInput);

    // Call the method to view daily statistics
    CovidAnalytics.viewDailyStatistics(date);
}
    private static void viewPatientStatusHistory(Scanner scanner) {
    System.out.println("\n--- View Patient Status History ---");

    System.out.print("Enter patient ID: ");
    int patientId = scanner.nextInt();

    // Call the method to view patient status history
    CovidAnalytics.viewPatientStatusHistory(patientId);
}
private static void viewDoctorAvailability(Scanner scanner) {
    System.out.println("\n--- View Doctor Availability ---");

    System.out.print("Enter doctor ID: ");
    int doctorId = scanner.nextInt();

    // Call the method to view doctor availability
    CovidAnalytics.viewDoctorAvailability(doctorId);
}
private static void viewHospitalOccupancy(Scanner scanner) {
    System.out.println("\n--- View Hospital Occupancy ---");

    System.out.print("Enter hospital ID: ");
    int hospitalId = scanner.nextInt();

    // Call the method to view hospital occupancy
    CovidAnalytics.viewHospitalOccupancy(hospitalId);
}
private static void viewTestResultsSummary(Scanner scanner) {
    System.out.println("\n--- View Test Results Summary ---");

    System.out.print("Enter test result: ");
    String result = scanner.next();

    // Call the method to view test results summary
    CovidAnalytics.viewTestResultsSummary(result);
}
private static void addMedicalInventoryItem(Scanner scanner) {
    System.out.println("\n--- Add Medical Inventory Item ---");

    System.out.print("Enter item name: ");
    String itemName = scanner.next();

    System.out.print("Enter quantity: ");
    int quantity = scanner.nextInt();

    System.out.print("Enter expiration date (YYYY-MM-DD): ");
    String expirationDateInput = scanner.next();
    LocalDate expirationDate = LocalDate.parse(expirationDateInput);

    // Call the method to add a new item to the medical inventory
    CovidAnalytics.addMedicalInventoryItem(itemName, quantity, expirationDate);

    System.out.println("Medical inventory item added successfully!");
}

private static void updateMedicalInventoryQuantity(Scanner scanner) {
    System.out.println("\n--- Update Medical Inventory Quantity ---");

    System.out.print("Enter inventory ID: ");
    int inventoryId = scanner.nextInt();

    System.out.print("Enter new quantity: ");
    int newQuantity = scanner.nextInt();

    // Call the method to update the quantity of an item in the medical inventory
    CovidAnalytics.updateMedicalInventoryQuantity(inventoryId, newQuantity);

    System.out.println("Medical inventory quantity updated successfully!");
}

private static void viewMedicalInventory() {
    System.out.println("\n--- View Medical Inventory ---");

    // Call the method to view the medical inventory
    CovidAnalytics.viewMedicalInventory();
}

private static void deleteMedicalInventoryItem(Scanner scanner) {
    System.out.println("\n--- Delete Medical Inventory Item ---");

    System.out.print("Enter inventory ID: ");
    int inventoryId = scanner.nextInt();

    // Call the method to delete an item from the medical inventory
    CovidAnalytics.deleteMedicalInventoryItem(inventoryId);

    System.out.println("Medical inventory item deleted successfully!");
}
private static void addPublicInformation(Scanner scanner) {
    System.out.println("\n--- Add Public Information Message ---");

    System.out.print("Enter message: ");
    String message = scanner.nextLine();  // Allow multi-line input

    System.out.print("Enter date (YYYY-MM-DD): ");
    String dateInput = scanner.next();
    LocalDate date = LocalDate.parse(dateInput);

    // Call the method to add a new public information message
    CovidAnalytics.addPublicInformation(message, date);

    System.out.println("Public information message added successfully!");
}

private static void viewPublicInformation() {
    System.out.println("\n--- View Public Information Messages ---");

    // Call the method to view public information messages
    CovidAnalytics.viewPublicInformation();
}
private static void addEmployeeHealthRecord(Scanner scanner) {
    System.out.println("\n--- Add Employee Health Record ---");

    System.out.print("Enter employee ID: ");
    int employeeId = scanner.nextInt();
    scanner.nextLine(); // Consume the newline character

    System.out.print("Enter health status: ");
    String status = scanner.nextLine();

    System.out.print("Enter date (YYYY-MM-DD): ");
    String dateInput = scanner.next();
    LocalDate date = LocalDate.parse(dateInput);

    // Call the method to add a new employee health record
    CovidAnalytics.addEmployeeHealthRecord(employeeId, status, date);

    System.out.println("Employee health record added successfully!");
}

private static void viewEmployeeHealthRecords(Scanner scanner) {
    System.out.println("\n--- View Employee Health Records ---");

    System.out.print("Enter employee ID: ");
    int employeeId = scanner.nextInt();

    // Call the method to view employee health records
    CovidAnalytics.viewEmployeeHealthRecords(employeeId);
}
private static void addEmergencyResponse(Scanner scanner) {
    System.out.println("\n--- Add Emergency Response Incident ---");

    System.out.print("Enter description: ");
    String description = scanner.nextLine();

    System.out.print("Enter location: ");
    String location = scanner.nextLine();

    System.out.print("Enter date and time (YYYY-MM-DD HH:mm:ss): ");
    String dateTimeInput = scanner.nextLine();
    LocalDateTime dateTime = LocalDateTime.parse(dateTimeInput, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

    // Call the method to add a new emergency response incident
    CovidAnalytics.addEmergencyResponse(description, location, dateTime);

    System.out.println("Emergency response incident added successfully!");
}

private static void viewEmergencyResponseIncidents() {
    // Call the method to view emergency response incidents
    CovidAnalytics.viewEmergencyResponseIncidents();
}
// Add this method to check if the user is logged in
private static void checkLogin() {
    if (!loggedIn) {
        System.out.println("Please log in first.");
        login();
    }
    else {
        System.out.println("You are already logged in.");
    }
    
}

private static void login() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Please enter your username:");
        String username = scanner.nextLine().trim();

        System.out.println("Please enter your password:");
        String password = scanner.nextLine().trim();

        // Call the SecurityManager to authenticate the user
        if (SecurityManager.authenticateUser(username, password)) {
            System.out.println("Login successful! You are now logged in as " + username);
        } else {
            System.out.println("Login failed. Invalid username or password.");
        }
    }

}





