/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mursa
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TestRequest {
    private int requestId;
    private int patientId;
    private LocalDate testDate;
    private String status;
    private String result;

    // Constructors
    public TestRequest() {
        // Default constructor
    }

    public TestRequest(int patientId, LocalDate testDate, String status, String result) {
        this.patientId = patientId;
        this.testDate = testDate;
        this.status = status;
        this.result = result;
    }

    // Getters and Setters
    public int getRequestId() {
        return requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public LocalDate getTestDate() {
        return testDate;
    }

    public void setTestDate(LocalDate testDate) {
        this.testDate = testDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    // CRUD Operations

    // Create
    public void requestTest() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO test_requests (patient_id, test_date, status, result) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setInt(1, this.patientId);
                preparedStatement.setObject(2, this.testDate);
                preparedStatement.setString(3, this.status);
                preparedStatement.setString(4, this.result);
                preparedStatement.executeUpdate();

                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    this.requestId = generatedKeys.getInt(1);
                }
            }
        } catch (SQLException e) {
        }
    }

    // Read
    public static List<TestRequest> getTestRequestsByPatient(int patientId) {
        List<TestRequest> testRequests = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM test_requests WHERE patient_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, patientId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        TestRequest testRequest = new TestRequest();
                        testRequest.setRequestId(resultSet.getInt("request_id"));
                        testRequest.setPatientId(resultSet.getInt("patient_id"));
                        testRequest.setTestDate(resultSet.getObject("test_date", LocalDate.class));
                        testRequest.setStatus(resultSet.getString("status"));
                        testRequest.setResult(resultSet.getString("result"));
                        testRequests.add(testRequest);
                    }
                }
            }
        } catch (SQLException e) {
        }
        return testRequests;
    }

    // Other CRUD methods for updating and deleting test requests
    // Inside the TestRequest class

// Update
public void updateTestRequestStatus(String newStatus) {
    try (Connection connection = DatabaseConnection.getConnection()) {
        String query = "UPDATE test_requests SET status=? WHERE request_id=?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, newStatus);
            preparedStatement.setInt(2, this.requestId);
            preparedStatement.executeUpdate();
        }
    } catch (SQLException e) {
    }
}

// Delete
public void cancelTestRequest() {
    try (Connection connection = DatabaseConnection.getConnection()) {
        String query = "DELETE FROM test_requests WHERE request_id=?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, this.requestId);
            preparedStatement.executeUpdate();
        }
    } catch (SQLException e) {
    }
}

}

