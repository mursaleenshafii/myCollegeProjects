/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mursa
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class CovidAnalytics {

    // Existing methods...

    // Method to record daily statistics
    public static void recordDailyStatistics(LocalDate date, int totalPatients, int totalDoctors,
                                             int totalAppointments, int newCases, int recoveredCases, int deaths) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO daily_statistics (date, total_patients, total_doctors, total_appointments, " +
                    "new_cases, recovered_cases, deaths) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setObject(1, date);
                preparedStatement.setInt(2, totalPatients);
                preparedStatement.setInt(3, totalDoctors);
                preparedStatement.setInt(4, totalAppointments);
                preparedStatement.setInt(5, newCases);
                preparedStatement.setInt(6, recoveredCases);
                preparedStatement.setInt(7, deaths);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    // Method to record patient status history
    public static void recordPatientStatusHistory(int patientId, String status, LocalDate statusDate) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO patient_status_history (patient_id, status, status_date) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, patientId);
                preparedStatement.setString(2, status);
                preparedStatement.setObject(3, statusDate);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    // Method to record doctor availability
    public static void recordDoctorAvailability(int doctorId, LocalDate date, int availableSlots, int bookedSlots) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO doctor_availability (doctor_id, date, available_slots, booked_slots) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, doctorId);
                preparedStatement.setObject(2, date);
                preparedStatement.setInt(3, availableSlots);
                preparedStatement.setInt(4, bookedSlots);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to record hospital occupancy
    public static void recordHospitalOccupancy(int hospitalId, LocalDate date, int totalBeds, int occupiedBeds) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO hospital_occupancy (hospital_id, date, total_beds, occupied_beds) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, hospitalId);
                preparedStatement.setObject(2, date);
                preparedStatement.setInt(3, totalBeds);
                preparedStatement.setInt(4, occupiedBeds);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    // Method to record test results summary
    public static void recordTestResultsSummary(String result, int totalTests, int positiveTests, int negativeTests) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO test_results_summary (result, total_tests, positive_tests, negative_tests) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, result);
                preparedStatement.setInt(2, totalTests);
                preparedStatement.setInt(3, positiveTests);
                preparedStatement.setInt(4, negativeTests);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }
public static void viewDailyStatistics(LocalDate date) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM daily_statistics WHERE date = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setObject(1, date);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        System.out.println("\n--- Daily Statistics ---");
                        System.out.println("Date: " + resultSet.getObject("date"));
                        System.out.println("Total Patients: " + resultSet.getInt("total_patients"));
                        System.out.println("Total Doctors: " + resultSet.getInt("total_doctors"));
                        System.out.println("Total Appointments: " + resultSet.getInt("total_appointments"));
                        System.out.println("New Cases: " + resultSet.getInt("new_cases"));
                        System.out.println("Recovered Cases: " + resultSet.getInt("recovered_cases"));
                        System.out.println("Deaths: " + resultSet.getInt("deaths"));
                    } else {
                        System.out.println("No daily statistics found for the given date.");
                    }
                }
            }
        } catch (SQLException e) {
        }
    }
    // ... Other methods based on your specific entity management requirements ...
public static void viewPatientStatusHistory(int patientId) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM patient_status_history WHERE patient_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, patientId);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    System.out.println("\n--- Patient Status History ---");
                    while (resultSet.next()) {
                        System.out.println("History ID: " + resultSet.getInt("history_id"));
                        System.out.println("Status: " + resultSet.getString("status"));
                        System.out.println("Status Date: " + resultSet.getObject("status_date"));
                        System.out.println("------");
                    }
                }
            }
        } catch (SQLException e) {
        }
    }
public static void viewDoctorAvailability(int doctorId) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM doctor_availability WHERE doctor_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, doctorId);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    System.out.println("\n--- Doctor Availability ---");
                    while (resultSet.next()) {
                        System.out.println("Availability ID: " + resultSet.getInt("availability_id"));
                        System.out.println("Date: " + resultSet.getObject("date"));
                        System.out.println("Available Slots: " + resultSet.getInt("available_slots"));
                        System.out.println("Booked Slots: " + resultSet.getInt("booked_slots"));
                        System.out.println("------");
                    }
                }
            }
        } catch (SQLException e) {
        }
    }
     public static void viewHospitalOccupancy(int hospitalId) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM hospital_occupancy WHERE hospital_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, hospitalId);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    System.out.println("\n--- Hospital Occupancy ---");
                    while (resultSet.next()) {
                        System.out.println("Occupancy ID: " + resultSet.getInt("occupancy_id"));
                        System.out.println("Date: " + resultSet.getObject("date"));
                        System.out.println("Total Beds: " + resultSet.getInt("total_beds"));
                        System.out.println("Occupied Beds: " + resultSet.getInt("occupied_beds"));
                        System.out.println("------");
                    }
                }
            }
        } catch (SQLException e) {
        }
    }
 // Method to view test results summary for a specific result
    public static void viewTestResultsSummary(String result) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM test_results_summary WHERE result = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, result);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    System.out.println("\n--- Test Results Summary ---");
                    while (resultSet.next()) {
                        System.out.println("Result: " + resultSet.getString("result"));
                        System.out.println("Total Tests: " + resultSet.getInt("total_tests"));
                        System.out.println("Positive Tests: " + resultSet.getInt("positive_tests"));
                        System.out.println("Negative Tests: " + resultSet.getInt("negative_tests"));
                        System.out.println("------");
                    }
                }
            }
        } catch (SQLException e) {
        }
    }
    public static void addMedicalInventoryItem(String itemName, int quantity, LocalDate expirationDate) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO medical_inventory (item_name, quantity, expiration_date) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, itemName);
                preparedStatement.setInt(2, quantity);
                preparedStatement.setObject(3, expirationDate);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    // Method to update the quantity of an item in the medical inventory
    public static void updateMedicalInventoryQuantity(int inventoryId, int newQuantity) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "UPDATE medical_inventory SET quantity = ? WHERE inventory_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, newQuantity);
                preparedStatement.setInt(2, inventoryId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    // Method to view the medical inventory
    public static void viewMedicalInventory() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM medical_inventory";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    System.out.println("\n--- Medical Inventory ---");
                    while (resultSet.next()) {
                        System.out.println("Inventory ID: " + resultSet.getInt("inventory_id"));
                        System.out.println("Item Name: " + resultSet.getString("item_name"));
                        System.out.println("Quantity: " + resultSet.getInt("quantity"));
                        System.out.println("Expiration Date: " + resultSet.getObject("expiration_date"));
                        System.out.println("------");
                    }
                }
            }
        } catch (SQLException e) {
        }
    }

    // Method to delete an item from the medical inventory
    public static void deleteMedicalInventoryItem(int inventoryId) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "DELETE FROM medical_inventory WHERE inventory_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, inventoryId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }
    // Method to add a new public information message
    public static void addPublicInformation(String message, LocalDate date) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO public_information (message, date) VALUES (?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, message);
                preparedStatement.setObject(2, date);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    // Method to view public information messages
    public static void viewPublicInformation() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM public_information";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    System.out.println("\n--- Public Information Messages ---");
                    while (resultSet.next()) {
                        System.out.println("Message ID: " + resultSet.getInt("message_id"));
                        System.out.println("Message: " + resultSet.getString("message"));
                        System.out.println("Date: " + resultSet.getObject("date"));
                        System.out.println("------");
                    }
                }
            }
        } catch (SQLException e) {
        }
    }

    // ... other methods ...
      public static void addEmployeeHealthRecord(int employeeId, String status, LocalDate date) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO employees (employee_id, status, date) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, employeeId);
                preparedStatement.setString(2, status);
                preparedStatement.setObject(3, date);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    // Method to view employee health records
    public static void viewEmployeeHealthRecords(int employeeId) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM employees WHERE employee_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, employeeId);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    System.out.println("\n--- Employee Health Records ---");
                    while (resultSet.next()) {
                        System.out.println("Record ID: " + resultSet.getInt("record_id"));
                        System.out.println("Status: " + resultSet.getString("status"));
                        System.out.println("Date: " + resultSet.getObject("date"));
                        System.out.println("------");
                    }
                }
            }
        } catch (SQLException e) {
        }
    }
    public static void addEmergencyResponse(String description, String location, LocalDateTime dateTime) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO emergency_response (description, location, date_time) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, description);
                preparedStatement.setString(2, location);
                preparedStatement.setObject(3, dateTime);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    // Method to view emergency response incidents
    public static void viewEmergencyResponseIncidents() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM emergency_response";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    System.out.println("\n--- Emergency Response Incidents ---");
                    while (resultSet.next()) {
                        System.out.println("Incident ID: " + resultSet.getInt("incident_id"));
                        System.out.println("Description: " + resultSet.getString("description"));
                        System.out.println("Location: " + resultSet.getString("location"));
                        System.out.println("Date Time: " + resultSet.getObject("date_time"));
                        System.out.println("Status: " + resultSet.getString("status"));
                        System.out.println("------");
                    }
                }
            }
        } catch (SQLException e) {
        }
    }


}
