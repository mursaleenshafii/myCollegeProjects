/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mursa
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Vaccination {
    private int vaccinationId;
    private int patientId;
    private String vaccineName;
    private int doseNumber;
    private LocalDate vaccinationDate;

    // Constructors
    public Vaccination() {
        // Default constructor
    }

    public Vaccination(int patientId, String vaccineName, int doseNumber, LocalDate vaccinationDate) {
        this.patientId = patientId;
        this.vaccineName = vaccineName;
        this.doseNumber = doseNumber;
        this.vaccinationDate = vaccinationDate;
    }

    // Getters and Setters
    public int getVaccinationId() {
        return vaccinationId;
    }

    public void setVaccinationId(int vaccinationId) {
        this.vaccinationId = vaccinationId;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public String getVaccineName() {
        return vaccineName;
    }

    public void setVaccineName(String vaccineName) {
        this.vaccineName = vaccineName;
    }

    public int getDoseNumber() {
        return doseNumber;
    }

    public void setDoseNumber(int doseNumber) {
        this.doseNumber = doseNumber;
    }

    public LocalDate getVaccinationDate() {
        return vaccinationDate;
    }

    public void setVaccinationDate(LocalDate vaccinationDate) {
        this.vaccinationDate = vaccinationDate;
    }

    // CRUD Operations

    // Create
    public void administerVaccination() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO vaccinations (patient_id, vaccine_name, dose_number, vaccination_date) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setInt(1, this.patientId);
                preparedStatement.setString(2, this.vaccineName);
                preparedStatement.setInt(3, this.doseNumber);
                preparedStatement.setObject(4, this.vaccinationDate);
                preparedStatement.executeUpdate();

                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    this.vaccinationId = generatedKeys.getInt(1);
                }
            }
        } catch (SQLException e) {
        }
    }

    // Read
    public static List<Vaccination> getVaccinationsByPatient(int patientId) {
        List<Vaccination> vaccinations = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM vaccinations WHERE patient_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, patientId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        Vaccination vaccination = new Vaccination();
                        vaccination.setVaccinationId(resultSet.getInt("vaccination_id"));
                        vaccination.setPatientId(resultSet.getInt("patient_id"));
                        vaccination.setVaccineName(resultSet.getString("vaccine_name"));
                        vaccination.setDoseNumber(resultSet.getInt("dose_number"));
                        vaccination.setVaccinationDate(resultSet.getObject("vaccination_date", LocalDate.class));
                        vaccinations.add(vaccination);
                    }
                }
            }
        } catch (SQLException e) {
        }
        return vaccinations;
    }

    // Other CRUD methods for updating and deleting vaccinations
    // Inside the Vaccination class

// Update
public void updateVaccinationDetails(String newVaccineName, int newDoseNumber, LocalDate newVaccinationDate) {
    try (Connection connection = DatabaseConnection.getConnection()) {
        String query = "UPDATE vaccinations SET vaccine_name=?, dose_number=?, vaccination_date=? WHERE vaccination_id=?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, newVaccineName);
            preparedStatement.setInt(2, newDoseNumber);
            preparedStatement.setObject(3, newVaccinationDate);
            preparedStatement.setInt(4, this.vaccinationId);
            preparedStatement.executeUpdate();
        }
    } catch (SQLException e) {
    }
}

// Delete
public void cancelVaccination() {
    try (Connection connection = DatabaseConnection.getConnection()) {
        String query = "DELETE FROM vaccinations WHERE vaccination_id=?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, this.vaccinationId);
            preparedStatement.executeUpdate();
        }
    } catch (SQLException e) {
    }
}

}

