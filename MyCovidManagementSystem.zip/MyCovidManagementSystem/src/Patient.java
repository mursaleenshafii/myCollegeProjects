/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author mursa
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Patient {
    private int patientId;
    private String name;
    private int age;
    private String address;
    private String status;
    private String testResult;
    

    // Constructors
    public Patient() {
        // Default constructor
    }

    public Patient(String name, int age, String address, String status, String testResult) {
        this.name = name;
        this.age = age;
        this.address = address;
        this.status = status;
        this.testResult = testResult;
    }

    // Getters and Setters
    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTestResult() {
        return testResult;
    }

    public void setTestResult(String testResult) {
        this.testResult = testResult;
    }

    // CRUD Operations
    public void save() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO patients (name, age, address, status, test_result) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, this.name);
                preparedStatement.setInt(2, this.age);
                preparedStatement.setString(3, this.address);
                preparedStatement.setString(4, this.status);
                preparedStatement.setString(5, this.testResult);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    public void update() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "UPDATE patients SET name=?, age=?, address=?, status=?, test_result=? WHERE patient_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, this.name);
                preparedStatement.setInt(2, this.age);
                preparedStatement.setString(3, this.address);
                preparedStatement.setString(4, this.status);
                preparedStatement.setString(5, this.testResult);
                preparedStatement.setInt(6, this.patientId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    public void delete() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "DELETE FROM patients WHERE patient_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, this.patientId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    public static List<Patient> getAllPatients() {
        List<Patient> patients = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM patients";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        Patient patient = new Patient();
                        patient.setPatientId(resultSet.getInt("patient_id"));
                        patient.setName(resultSet.getString("name"));
                        patient.setAge(resultSet.getInt("age"));
                        patient.setAddress(resultSet.getString("address"));
                        patient.setStatus(resultSet.getString("status"));
                        patient.setTestResult(resultSet.getString("test_result"));
                        patients.add(patient);
                    }
                }
            }
        } catch (SQLException e) {
        }
        return patients;
    }
    public static Patient getPatientById(int patientId) {
        Patient patient = null;
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM patients WHERE patient_id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, patientId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        patient = new Patient();
                        patient.setPatientId(resultSet.getInt("patient_id"));
                        patient.setName(resultSet.getString("name"));
                      
                        // Set other properties as needed
                    }
                }
            }
        } catch (SQLException e) {
        }
        return patient;
    }

}

