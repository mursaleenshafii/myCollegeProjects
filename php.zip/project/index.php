<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page</title>
  <link rel="stylesheet" href="./styles/login.css"> 
  <style>
    .error-message {
      color: red;
      font-size: 14px;
    }
  </style>
</head>

<body>
  <div class="login-container">
    <h1>Login</h1>
    <form id="login-form" class="form-container" method="post" onsubmit="hideErrorMessage();">
      <input class="input-field" type="text" id="username" name="username" placeholder="Username" required>
      <input class="input-field" type="password" id="password" name="password" placeholder="Password" required>
      <button class="btn-login" type="submit" name="login">Login</button>
      <?php
        if (isset($_POST['login'])) {
          $username = $_POST['username'];
          $password = $_POST['password'];

          // Dummy database check
          $correctUsername = 'admin';
          $correctPassword = 'admin';

          // Check if the entered username and password are correct
          if ($username === $correctUsername && $password === $correctPassword) {
            header('Location: profile.html');
            exit;
          } else {
            echo '<p class="error-message">Login failed. Please check your credentials.</p>';
          }
        }
      ?>
    </form>
  </div>
</body>
</html>
